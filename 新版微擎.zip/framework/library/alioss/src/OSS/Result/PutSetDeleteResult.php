<?php

namespace OSS\Result;


/**
 * Class PutSetDeleteResult
 * @package OSS\Result
 */
class PutSetDeleteResult extends Result
{
    /**
     * @return null
     */
    protected function parseDataFromResponse()
    {
        return null;
    }
}